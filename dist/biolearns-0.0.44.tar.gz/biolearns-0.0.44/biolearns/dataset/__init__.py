# __init__.py
from ._TCGA import *
