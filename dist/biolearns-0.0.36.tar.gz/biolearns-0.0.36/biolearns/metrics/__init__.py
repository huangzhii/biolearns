# __init__.py
from .discriminant import *
